// Background service worker for handling AI API requests

const SYSTEM_PROMPT = `You are an expert solving Cisco NetAcad / CCNA quizzes.

Very important rules – follow exactly:

• If the question asks for ONE correct answer (or nothing is said about the number) → return ONLY ONE letter
• If the question says "select two", "select three", "select all that apply", "choose all correct", "two answers are correct", "multiple answers", "all that apply" or similar wording → return ALL correct letters

Output format – ONLY this, nothing else:

Single answer    →   A
Multiple answers →   A,C,E

Additional rules:
- ONLY uppercase letters A,B,C,D
- If multiple → comma separated, NO spaces after commas (np. A,C,E)
- NO explanation
- NO additional text
- NO dot, colon, space except between letters and comma
- If you are unsure, still return the most likely answer(s)
`;

const temperature = 0.1;          // lekko podniesione – pomaga przy multi-select
const top_p = 0.95;
const max_tokens = 100;           // wystarczy na listę liter
const presence_penalty = 0;
const frequency_penalty = 0;

// OpenRouter Model Mapping (bez zmian)
const OPENROUTER_MODELS = {
  "DeepSeek": "deepseek/deepseek-v3.2-exp",
  "GPT-5 Pro": "openai/gpt-5-pro",
  "Claude Sonnet 4.5": "anthropic/claude-sonnet-4.5",
  "Qwen3 Coder Plus": "qwen/qwen3-coder-plus",
  "GLM": "z-ai/glm-4.6",
  "Grok 4 Fast": "x-ai/grok-4-fast",
  "GPT-5 Codex": "openai/gpt-5-codex",
  "Qwen3 Coder Flash": "qwen/qwen3-coder-flash"
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getAnswer') {
    handleGetAnswer(request.question, request.options, request.modelType)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // async
  }
});

async function handleGetAnswer(question, options, modelType = 'simple') {
  try {
    const settings = await chrome.storage.sync.get([
      'simpleModel', 
      'codingModel', 
      'openRouterApiKey',
      'aiProvider',
      'apiKey'
    ]);

    let provider, modelId, apiKey;

    if (modelType === 'simple') {
      modelId = settings.simpleModel;
    } else if (modelType === 'coding') {
      modelId = settings.codingModel;
    }

    if (modelId && OPENROUTER_MODELS[modelId]) {
      provider = 'openrouter';
      apiKey = settings.openRouterApiKey;
      if (!apiKey) throw new Error('OpenRouter API key not set.');
    } else if (modelId === 'groq' || modelId === 'gemini') {
      provider = modelId;
      apiKey = settings.apiKey;
      if (!apiKey) throw new Error('API key not set.');
    } else {
      provider = settings.aiProvider || 'groq';
      apiKey = settings.apiKey;
      if (!apiKey) throw new Error('API key not set.');
    }

    let answerIndices;  // teraz tablica

    if (provider === 'gemini') {
      answerIndices = await getAnswerFromGemini(question, options, apiKey);
    } else if (provider === 'groq') {
      answerIndices = await getAnswerFromGroq(question, options, apiKey);
    } else if (provider === 'openrouter') {
      answerIndices = await getAnswerFromOpenRouter(question, options, modelId, apiKey);
    } else {
      throw new Error('Unknown provider: ' + provider);
    }

    return { success: true, answerIndices };   // ← zwracamy answerIndices (tablica)
  } catch (error) {
    console.error('Error in handleGetAnswer:', error);
    return { success: false, error: error.message };
  }
}

// ────────────────────────────────────────────────
// Wspólna funkcja parsująca odpowiedź → tablica indeksów
// ────────────────────────────────────────────────

function parseAnswerToIndices(answerText) {
  if (!answerText) throw new Error('Empty response from model');

  const cleaned = answerText.trim().toUpperCase().replace(/\s+/g, '');

  const letters = cleaned
    .split(',')
    .map(l => l.trim())
    .filter(l => /^[A-J]$/.test(l));   // ← zmienione na A-J

  if (letters.length === 0) {
    console.warn(`No valid letters A-J found in: "${answerText}" – returning first letter if possible`);
    // Fallback – jeśli jest choć jedna litera A-Z
    const fallback = cleaned.match(/[A-J]/);
    if (fallback) {
      return [fallback[0].charCodeAt(0) - 65];
    }
    throw new Error(`No valid A-J letters found in: "${answerText}"`);
  }

  const indices = letters.map(l => l.charCodeAt(0) - 65);
  console.log(`Parsed: "${answerText}" → letters: ${letters} → indices: ${indices}`);
  return indices;
}

// ────────────────────────────────────────────────
// Gemini – zmienione
// ────────────────────────────────────────────────

async function getAnswerFromGemini(question, options, apiKey) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

  const formattedOptions = options.map((opt, idx) => 
    `${String.fromCharCode(65 + idx)}. ${opt}`
  ).join('\n');

  const prompt = `Question: ${question}\n\nOptions:\n${formattedOptions}\n\nAnswer following the system instructions exactly.`;

  const requestBody = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature, top_p, max_tokens, presence_penalty, frequency_penalty
    },
    safetySettings: [
      { category: "HARM_CATEGORY_HARASSMENT",     threshold: "BLOCK_NONE" },
      { category: "HARM_CATEGORY_HATE_SPEECH",     threshold: "BLOCK_NONE" },
      { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
      { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
    ]
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(requestBody)
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(`Gemini error: ${err.error?.message || response.statusText}`);
  }

  const data = await response.json();
  const answerText = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

  if (!answerText) throw new Error('No text in Gemini response');

  return parseAnswerToIndices(answerText);
}

// ────────────────────────────────────────────────
// OpenRouter – zmienione
// ────────────────────────────────────────────────

async function getAnswerFromOpenRouter(question, options, modelName, apiKey) {
  const url = 'https://openrouter.ai/api/v1/chat/completions';

  const formattedOptions = options.map((opt, idx) => 
    `${String.fromCharCode(65 + idx)}. ${opt}`
  ).join('\n');

  const prompt = `Question: ${question}\n\nOptions:\n${formattedOptions}\n\nAnswer following the system instructions exactly.`;

  const requestBody = {
    model: OPENROUTER_MODELS[modelName],
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user',   content: prompt }
    ],
    temperature, top_p, max_tokens, presence_penalty, frequency_penalty
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify(requestBody)
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(`OpenRouter error: ${err.error?.message || response.statusText}`);
  }

  const data = await response.json();
  const answerText = data.choices?.[0]?.message?.content?.trim();

  if (!answerText) throw new Error('No content in OpenRouter response');

  return parseAnswerToIndices(answerText);
}

// ────────────────────────────────────────────────
// Groq – zmienione
// ────────────────────────────────────────────────

async function getAnswerFromGroq(question, options, apiKey) {
  const url = 'https://api.groq.com/openai/v1/chat/completions';

  const formattedOptions = options.map((opt, idx) => 
    `${String.fromCharCode(65 + idx)}. ${opt}`
  ).join('\n');

  const prompt = `Question: ${question}\n\nOptions:\n${formattedOptions}\n\nAnswer following the system instructions exactly.`;

  const requestBody = {
    model: 'llama-3.3-70b-versatile',
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user',   content: prompt }
    ],
    temperature, top_p, max_tokens, presence_penalty, frequency_penalty
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify(requestBody)
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(`Groq error: ${err.error?.message || response.statusText}`);
  }

  const data = await response.json();
  const answerText = data.choices?.[0]?.message?.content?.trim();

  if (!answerText) throw new Error('No content in Groq response');

  return parseAnswerToIndices(answerText);
}