// Content script for Netacad Quiz Helper
console.log('Netacad Quiz Helper: Content script loaded in quiz iframe');
console.log('Current URL:', window.location.href);

// ────────────────────────────────────────────────
// Funkcje pomocnicze (bez zmian – zostawiam oryginalne)
// ────────────────────────────────────────────────

function findInShadowDOM(selector, root = document) {
  let elements = Array.from(root.querySelectorAll(selector));
  const allElements = root.querySelectorAll('*');
  allElements.forEach(el => {
    if (el.shadowRoot) {
      elements = elements.concat(findInShadowDOM(selector, el.shadowRoot));
    }
  });
  return elements;
}

function getTextFromShadowElement(element) {
  if (!element) return '';
  if (element.textContent && element.textContent.trim()) {
    return element.textContent.trim();
  }
  if (element.shadowRoot) {
    return element.shadowRoot.textContent?.trim() || '';
  }
  return '';
}

async function waitForElement(parentElement, selector, maxAttempts = 20) {
  for (let i = 0; i < maxAttempts; i++) {
    const element = parentElement.querySelector(selector);
    if (element) return element;
    await new Promise(r => setTimeout(r, 100));
  }
  return null;
}

async function waitForShadowContent(element, maxAttempts = 20) {
  if (!element || !element.shadowRoot) return null;
  for (let i = 0; i < maxAttempts; i++) {
    if (element.shadowRoot.children.length > 0) {
      return element.shadowRoot;
    }
    await new Promise(r => setTimeout(r, 100));
  }
  return element.shadowRoot;
}

function findElementInShadowDOM(root, selector) {
  let element = root.querySelector(selector);
  if (element) return element;
  const allElements = root.querySelectorAll('*');
  for (let el of allElements) {
    if (el.shadowRoot) {
      element = findElementInShadowDOM(el.shadowRoot, selector);
      if (element) return element;
    }
  }
  return null;
}

// ────────────────────────────────────────────────
// extractQuestionData – bez zmian (oryginał)
// ────────────────────────────────────────────────

async function extractQuestionData() {
  console.log('=== Starting Question Extraction ===');
  try {
    console.log('🔍 Searching for active mcq-view...');
    let allMcqViews = [];
    function findAllMcqViews(root) {
      const mcqViews = root.querySelectorAll('mcq-view');
      allMcqViews.push(...mcqViews);
      const allElements = root.querySelectorAll('*');
      for (let el of allElements) {
        if (el.shadowRoot) findAllMcqViews(el.shadowRoot);
      }
    }
    findAllMcqViews(document);
    console.log(`Found ${allMcqViews.length} total mcq-view elements`);

    if (allMcqViews.length === 0) {
      console.log('❌ No mcq-view found');
      return null;
    }

    let mcqViewElement = null;
    let visibleMcqViews = [];
    for (let mcq of allMcqViews) {
      const parent = mcq.closest('.block__container, [class*="block"]');
      if (parent) {
        const style = window.getComputedStyle(parent);
        const isVisible = style.display !== 'none' &&
                          style.visibility !== 'hidden' &&
                          style.opacity !== '0';
        const hasActiveClass = parent.classList.contains('animate') ||
                               parent.classList.contains('active') ||
                               parent.classList.contains('is-active');
        if (isVisible) visibleMcqViews.push(mcq);
      }
    }

    if (visibleMcqViews.length > 0) {
      mcqViewElement = visibleMcqViews[visibleMcqViews.length - 1];
      console.log(`✅ Found active mcq-view (last visible)`);
    } else if (allMcqViews.length > 0) {
      mcqViewElement = allMcqViews[allMcqViews.length - 1];
      console.log('✅ Using last mcq-view (fallback)');
    }

    if (!mcqViewElement) return null;

    if (!mcqViewElement.shadowRoot) return null;
    let mcqView = mcqViewElement.shadowRoot.querySelector("div");
    if (!mcqView) return null;

    let headerContainer = mcqView.querySelector("div[class='component__header-container']");
    if (!headerContainer) return null;

    let baseView = headerContainer.querySelector("base-view");
    if (!baseView || !baseView.shadowRoot) return null;

    let bodyInner = baseView.shadowRoot.querySelector("div[class='component__body-inner mcq__body-inner']");
    if (!bodyInner) return null;

    let questionText = bodyInner.textContent.trim();

    let codeText = '';
    const codeWithMcq = mcqView.querySelector('code-with-mcq');
    if (codeWithMcq && codeWithMcq.shadowRoot) {
      const codeComponent = codeWithMcq.shadowRoot.querySelector("div[class='component']");
      if (codeComponent) {
        codeText = codeComponent.textContent.trim();
        questionText += '\n\nCode:\n' + codeText;
      }
    }

    let optionNodes = mcqView.querySelectorAll('.mcq__item-text-inner');
    if (optionNodes.length === 0) return null;

    let options = Array.from(optionNodes).map((node, index) => ({
      index,
      text: node.textContent.trim(),
      element: node.closest('.mcq__item')
    }));

    return { question: questionText, options };
  } catch (error) {
    console.error('❌ Extraction error:', error);
    return null;
  }
}

// ────────────────────────────────────────────────
// NOWA WERSJA – highlightCorrectAnswer obsługuje wiele odpowiedzi
// ────────────────────────────────────────────────

function highlightCorrectAnswer(correctIndices) {
  console.log('=== Starting Multi-Highlight ===');
  console.log('Indices to highlight:', correctIndices);

  // Jeśli przyszła pojedyncza liczba → traktujemy jako tablicę
  if (!Array.isArray(correctIndices)) {
    correctIndices = [Number(correctIndices)].filter(n => !isNaN(n));
  }

  try {
    // Szukamy aktywnego mcq-view (ta sama logika co w extract)
    let allMcqViews = [];
    function findAllMcqViews(root) {
      const mcqViews = root.querySelectorAll('mcq-view');
      allMcqViews.push(...mcqViews);
      const allElements = root.querySelectorAll('*');
      for (let el of allElements) {
        if (el.shadowRoot) findAllMcqViews(el.shadowRoot);
      }
    }
    findAllMcqViews(document);

    if (allMcqViews.length === 0) {
      console.log('❌ No mcq-view for highlighting');
      return;
    }

    let mcqViewElement = null;
    let visibleMcqViews = [];

    for (let mcq of allMcqViews) {
      const parent = mcq.closest('.block__container, [class*="block"]');
      if (parent) {
        const style = window.getComputedStyle(parent);
        const isVisible = style.display !== 'none' &&
                          style.visibility !== 'hidden' &&
                          style.opacity !== '0';
        if (isVisible) visibleMcqViews.push(mcq);
      }
    }

    if (visibleMcqViews.length > 0) {
      mcqViewElement = visibleMcqViews[visibleMcqViews.length - 1];
    } else if (allMcqViews.length > 0) {
      mcqViewElement = allMcqViews[allMcqViews.length - 1];
    }

    if (!mcqViewElement || !mcqViewElement.shadowRoot) {
      console.log('❌ No valid mcq-view shadow root');
      return;
    }

    let mcqView = mcqViewElement.shadowRoot.querySelector("div");
    if (!mcqView) return;

    const optionElements = mcqView.querySelectorAll('.mcq__item');
    console.log(`Found ${optionElements.length} options to highlight`);

    // Usuwamy stare podświetlenia
    optionElements.forEach(el => {
      el.classList.remove('ai-correct-answer');
      el.style.backgroundColor = '';
      el.style.border = '';
      el.style.boxShadow = '';
      el.style.color = '';
      const texts = el.querySelectorAll('*');
      texts.forEach(t => t.style.color = '');
    });

    let highlightedCount = 0;

    correctIndices.forEach(rawIndex => {
      const index = Number(rawIndex);
      if (!isNaN(index) && index >= 0 && index < optionElements.length) {
        const el = optionElements[index];
        el.classList.add('ai-correct-answer');

        el.style.backgroundColor = '#22c55e';
        el.style.border = '3px solid #16a34a';
        el.style.borderRadius = '8px';
        el.style.boxShadow = '0 0 0 4px rgba(34, 197, 94, 0.2)';
        el.style.color = 'white';

        const texts = el.querySelectorAll('*');
        texts.forEach(t => t.style.color = 'white');

        highlightedCount++;
        console.log(`Highlighted option #${index}`);
      }
    });

    console.log(`Highlighted ${highlightedCount} options`);
    console.log('=== Multi-Highlight Complete ===\n');
  } catch (error) {
    console.error('Highlight error:', error);
  }
}

// ────────────────────────────────────────────────
// Tworzenie przycisków – bez zmian
// ────────────────────────────────────────────────

function createHelperButton(targetDocument = document) {
  if (document.getElementById('netacad-ai-helper-btn-simple')) {
    console.log('Buttons already exist');
    return;
  }

  const simpleButton = targetDocument.createElement('button');
  simpleButton.id = 'netacad-ai-helper-btn-simple';
  simpleButton.innerHTML = '🤖 Get AI Answer';
  simpleButton.className = 'ai-helper-button ai-helper-button-simple';

  const advancedButton = targetDocument.createElement('button');
  advancedButton.id = 'netacad-ai-helper-btn-advanced';
  advancedButton.innerHTML = '🔥 Advanced AI (Code/Math)';
  advancedButton.className = 'ai-helper-button ai-helper-button-advanced';

  simpleButton.addEventListener('click', async () => {
    await handleButtonClick(simpleButton, 'simple', '🤖 Get AI Answer');
  });

  advancedButton.addEventListener('click', async () => {
    await handleButtonClick(advancedButton, 'coding', '🔥 Advanced AI (Code/Math)');
  });

  targetDocument.body.appendChild(simpleButton);
  targetDocument.body.appendChild(advancedButton);
  console.log('Buttons added');
}

// ────────────────────────────────────────────────
// Obsługa kliknięcia przycisku – ZMIENIONE wywołanie highlight
// ────────────────────────────────────────────────

async function handleButtonClick(button, modelType, originalText) {
  button.disabled = true;
  button.innerHTML = '⏳ Analyzing...';

  const questionData = await extractQuestionData();

  if (!questionData) {
    alert('Could not extract question data.');
    button.disabled = false;
    button.innerHTML = originalText;
    return;
  }

  try {
    const response = await chrome.runtime.sendMessage({
      action: 'getAnswer',
      question: questionData.question,
      options: questionData.options.map(opt => opt.text),
      modelType
    });

    console.log('AI Response:', response);

    if (response.success) {
      // ← ZMIANA: używamy answerIndices (tablica)
      highlightCorrectAnswer(response.answerIndices);
      button.innerHTML = '✅ Answer Highlighted';
      setTimeout(() => {
        button.innerHTML = originalText;
        button.disabled = false;
      }, 2000);
    } else {
      alert('AI Error: ' + response.error);
      button.disabled = false;
      button.innerHTML = originalText;
    }
  } catch (error) {
    console.error('Error:', error);
    alert('Error communicating with AI.');
    button.disabled = false;
    button.innerHTML = originalText;
  }
}

// ────────────────────────────────────────────────
// Inicjalizacja i obserwacja – bez zmian
// ────────────────────────────────────────────────

function checkForQuiz() {
  const appRoot = document.querySelector('app-root');
  const buttonsExist = document.getElementById('netacad-ai-helper-btn-simple');
  if (appRoot && !buttonsExist) {
    createHelperButton(document);
  }
}

let checkAttempts = 0;
const maxAttempts = 20;

function tryCheckForQuiz() {
  checkAttempts++;
  checkForQuiz();
  if (checkAttempts < maxAttempts && !document.getElementById('netacad-ai-helper-btn-simple')) {
    setTimeout(tryCheckForQuiz, 500);
  }
}

function initialize() {
  setTimeout(tryCheckForQuiz, 1000);

  const observer = new MutationObserver(() => {
    if (!document.getElementById('netacad-ai-helper-btn-simple')) {
      if (document.querySelector('app-root')) {
        checkForQuiz();
      }
    }
  });

  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => setTimeout(initialize, 500));
} else {
  initialize();
}